
#ifndef GRAFOS_M
#define GRAFOS_M


typedef struct grafo{

	int n_vertices;
	char dir;
	struct no **mat;

}t_grafo_m;


typedef struct no{
	int peso;
}t_no;

typedef struct coordenada{
	int v1;	
	int v2;
	int peso;	
}t_coordenada;


t_grafo_m* cria_grafo_m(int n_vertices,char dir);
void v_adjacentes(t_grafo_m* g,int id_vertice, int n_vertices);
void exibe_matriz(t_grafo_m* g,int n_vertices,int transposta);
void le_coordenada(t_coordenada *aux);
void remove_aresta(t_grafo_m* g,t_coordenada *aux);
void adiciona_aresta(t_grafo_m* g,t_coordenada *aux);
void aresta_menor(t_grafo_m* g,int n_vertices);

#endif