#include <stdio.h>
#include <string.h>
#include "matriz.h"
#include "lista_adjacencia.h"

int main(){

	char t_grafo,dir,operacao[3];
	int n_vertices,n_arestas,id_aux;

	scanf("%c %c",&dir,&t_grafo);
	scanf("%d %d",&n_vertices,&n_arestas);

	if(t_grafo == 'M'){
		
		t_coordenada aux;
		t_grafo_m *g = cria_grafo_m(n_vertices,dir);

		while(n_arestas > 0){
			le_coordenada(&aux);
			//printf("Vertice 1 -> %d Vertice 2 -> %d Peso -> %d\n", aux.v1,aux.v2,aux.peso);
			adiciona_aresta(g,&aux);	
			n_arestas--;
		}

		
		while(scanf("%s",operacao) != EOF){
			operacao[2] = '\0';
			if(strcmp(operacao,"IG") == 0){
			exibe_matriz(g,n_vertices,0);
			}else if(strcmp(operacao,"VA") == 0){
				scanf("%d",&id_aux);
				v_adjacentes(g,id_aux,n_vertices);
			}else if(strcmp(operacao,"AA") == 0){
				le_coordenada(&aux);
				g->mat[aux.v1][aux.v2].peso = aux.peso;	
				g->mat[aux.v2][aux.v1].peso = aux.peso;
			}else if(strcmp(operacao,"IT") == 0){
				exibe_matriz(g,n_vertices,1);
			}else if(strcmp(operacao,"RA") == 0){
				le_coordenada(&aux);
				remove_aresta(g,&aux);
			}else if(strcmp(operacao,"MP") == 0){
				aresta_menor(g,g->n_vertices);
			}
		}

	}else{

		t_coordenada_l aux;
		t_grafo_l *g = cria_grafo_l(n_vertices,dir);

		while(n_arestas > 0){
			le_coordenada_l(&aux);
			//printf("Vertice 1 -> %d Vertice 2 -> %d Peso -> %d\n", aux.v1,aux.v2,aux.peso);
			adiciona_aresta_l(g,&aux);	
			n_arestas--;
		}

		
		while(scanf("%s",operacao) != EOF){
			operacao[2] = '\0';
			if(strcmp(operacao,"IG") == 0){
				exibe_grafo_l(g,n_vertices,0);
			}else if(strcmp(operacao,"IT") == 0){
				exibe_grafo_l(g,n_vertices,1);
			}else if(strcmp(operacao,"AA") == 0){
				le_coordenada_l(&aux);
				adiciona_aresta_l(g,&aux);	
			}else if(strcmp(operacao,"RA") == 0){
				le_coordenada_l(&aux);
				remove_aresta_l(g,&aux);
			}else if(strcmp(operacao,"MP") == 0){
				aresta_menor_l(g,g->n_vertices);
			}
		}

	}
	
	

	

}